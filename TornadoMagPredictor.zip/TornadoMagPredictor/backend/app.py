from flask import Flask, request
from flask_cors import CORS
import pandas as pd
import pickle
from sklearn.preprocessing import MinMaxScaler
from geopy.geocoders import Nominatim

app = Flask(__name__)
CORS(app)

model = pickle.load(open('model.pkl', 'rb'))
tornado_df = pd.read_csv('cleaned.csv')


@app.route("/predict", methods=["POST"])
def predict():
    if request.method == "POST":
        leng = float(request.form["leng"])
        wid = float(request.form["wid"])
        fat = float(request.form["fat"])
        place = request.form["place"]
        locator = Nominatim(user_agent="myAppGeocoder")
        location = locator.geocode(place)
        slat = location.latitude
        slon = location.longitude

        data = [[fat, leng, wid, slat, slon]]
        user_df = pd.DataFrame(data, columns=["fat", "len", "wid", "slat", "slon"])
        features = tornado_df
        complete = pd.concat([features, user_df]).reset_index(drop=True)
        scaler = MinMaxScaler()
        scaled_df = scaler.fit_transform(complete)
        output = model.predict([list(scaled_df[-1])])

        category = ""
        if(output[0] == 0):
            category = "EF 0 - Light damage"
        elif(output[0] == 1):
            category = "EF 1 - Moderate damage"
        elif(output[0] == 2):
            category = "EF 2 - Considerable damage"
        elif(output[0] == 3):
            category = "EF 3 - Severe damage"
        elif(output[0] == 4):
            category = "EF 4 - Devastating damage"
        elif(output[0] == 5):
            category = "EF 5 - Incredible damage"
        return { "classify": category }

if __name__ == "__main__":
    app.run(debug=False)
